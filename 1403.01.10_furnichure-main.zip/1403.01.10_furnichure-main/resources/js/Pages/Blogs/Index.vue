<template>
    <div>Test</div>
</template>
<script setup>
import { ref } from "vue";
</script>
