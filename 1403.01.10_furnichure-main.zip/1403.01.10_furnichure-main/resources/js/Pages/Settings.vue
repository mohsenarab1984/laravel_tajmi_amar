<template>
    <Head>
        <title>Settings</title>
    </Head>
    <h2>Settings</h2>
</template>
<script setup>
import { Link } from "@inertiajs/vue3";
import Nav from "../shared/Nav.vue";
// import { Head } from "@inertiajs/vue3";
// import Layout from "../shared/Layout.vue";
// defineOptions({ layout: Layout });
</script>
