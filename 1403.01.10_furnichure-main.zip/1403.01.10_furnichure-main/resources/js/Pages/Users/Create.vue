<template>
    <Head title="create user" />
    <h1 class="text-3xl">create new user</h1>

    <form action="" method="POST"></form>
</template>
<script setup>
import { ref } from "vue";
</script>
