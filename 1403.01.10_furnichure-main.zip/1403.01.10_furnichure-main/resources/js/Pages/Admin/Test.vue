<template>
    <div>Admin.Blog.Test</div>
</template>
<script setup>
import { ref } from "vue";
</script>
